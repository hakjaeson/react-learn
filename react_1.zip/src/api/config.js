// export const SERVER_URL = "http://192.168.0.66:5000";
export const SERVER_URL = "";
