import React from "react";

const ModifyComponent = () => {
  return <div>수정입력창 작업 필요</div>;
};

export default ModifyComponent;
