import React from "react";

const Map = () => {
  return <h3>Map</h3>;
};

export default Map;
