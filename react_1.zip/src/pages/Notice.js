import React from "react";

const Notice = () => {
  return <div>Notice</div>;
};

export default Notice;
