import React from "react";

const NotFound = () => {
  return <div>잘못된 경로로 접근하셨습니다.</div>;
};

export default NotFound;
