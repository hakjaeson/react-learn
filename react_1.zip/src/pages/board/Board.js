import React, { useState } from "react";
// 미리보기 이미지 초기값
const initPreview = "";
const Board = () => {
  // 미리보기 이미지
  const [previewImg, setPreviewImg] = useState(initPreview);
  // 선택된 파일(데이터 종류)
  const [selectFile, setSelectFile] = useState(null);

  // 이미지 파일 선택 미리보기
  const handleChangeFile = e => {
    const file = e.target.files[0];
    if (file) {
      const tempUrl = URL.createObjectURL(file);
      // 미리보기 state
      setPreviewImg(tempUrl);
      // 파일 보관
      setSelectFile(file);
    }
  };
  return (
    <div>
      <h2>파이어베이스 이미지 업로드 / 미리보기 </h2>
      <hr />
      <div>
        <h3>미리보기</h3>
        {/* {previewImg ? <img src={previewImg} alt="미리보기" /> : "없어요"} */}
        {previewImg && <img src={previewImg} alt="미리보기" />}
      </div>
      <hr />
      <div>
        <h3>이미지 업로드 하기</h3>
        <input
          type="file"
          accept="image/png, image/gif, image/jpeg"
          onChange={e => {
            handleChangeFile(e);
          }}
        />
        <button>업로드</button>
      </div>
      <hr />
      <div>
        <h3>업로드된 이미지 경로 : </h3>
      </div>
      <hr />
      <div>
        <h3>업로드된 이미지 경로를 직접 입력하기</h3>
        <input type="text" />
      </div>
      <hr />
      <div>
        <h3>업로드된 전체 이미지 목록 가져오기</h3>
        <button>전체 목록 보기</button>
      </div>
      <hr />
    </div>
  );
};

export default Board;
