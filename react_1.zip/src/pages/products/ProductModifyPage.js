import React from "react";

const ProductModifyPage = () => {
  return <div>ProductModifyPage</div>;
};

export default ProductModifyPage;
