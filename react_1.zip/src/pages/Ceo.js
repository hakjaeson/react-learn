import React from "react";

const Ceo = () => {
  return <h3>Ceo</h3>;
};

export default Ceo;
