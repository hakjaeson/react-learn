# React 공부하기

## 8. React Router

- Router(라우터) : URI 경로를 동기화하여 화면의 전환, 흐름을 제어한다.
- HTML 이동을 하지 않고 내용을 갱신합니다.
- `npm install react-router` 를 설치하고 활용합니다.
- `npm install react-router-dom`를 설치하고 활용합니다.

### 8.9. useSearchParams 를 통해 쿼리스트링( Query String ) 활용하기

- http://127.0.0.1:3000?no=1&msg=안녕&id=hong
- http://127.0.0.1:3000 는 URL
- ? 는 쿼리 구분자
- no=1&msg=안녕&id=hong 쿼리 스트링
- & 는 쿼리 항목 구분자
- 예) no=1 쿼리로서 no라는 변수에 값 1을 담아서 URL 로 전달

/src/App.js

```js
<Route path="/about" element={<About title="우리서비스소개" />}>
  {/* Outelet 컴포넌트 초기화면은 index 로 셋트 */}
  <Route index element={<Ceo />}></Route>
  <Route path="ceo" element={<Ceo />}></Route>
  <Route path="map" element={<Map />}></Route>
  <Route path="notice" element={<Notice />}></Route>
</Route>
```

/src/pages/About.js

```js
import React from "react";
import { Link, Outlet } from "react-router-dom";

const About = ({ title }) => {
  return (
    <div>
      <h2>About : {title}</h2>
      <div>
        <Link to="/about/ceo">Ceo 인사말</Link>
        <br />
        <Link to="/about/map">회사위치</Link>
        <br />
        <Link to="/about/notice">공지사항</Link>
      </div>
      <Outlet />
    </div>
  );
};

export default About;
```

/src/pages/Notice.js

```js
import React from "react";

const Notice = () => {
  return <div>Notice</div>;
};

export default Notice;
```
