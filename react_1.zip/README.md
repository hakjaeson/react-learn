# JWT 인증

- JSON Web Token 의 줄임말
- Token 은 복잡한 문자열
- Access Token
  : 자료 요청(axios) 시 먼저 전달
  : 약속된 Access Token 이 없으면 거부 합니다.

- Refresh Token
  : Access Token 은 만료시간이 있어요. (30분 ~1시간)
  : Access Token 이 거부되면 Refresh Token 프론트 전달
  : 다시 Access Token 과 Referesh Token 재발근

- axios에서 intecepter 설정
  : API 백엔드 서버에 전달하기 전과 후에 미리 토큰 전달

## 1. intercepter 셋팅
- /src/util/jwtUtil.js
 : jwt 인증 전용 axios